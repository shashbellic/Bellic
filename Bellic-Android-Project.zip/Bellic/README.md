# Bellic — local Android backup

Bellic is a small Android utility intended to back up only:

- Contacts to `Contacts/contacts.vcf`
- Photos to `Photos/`
- Videos to `Videos/`

It saves a snapshot into a user-selected storage location using this layout:

```text
<selected parent>/
└── CurrentStateBackup/
    ├── 2026-10-13_02-00-00/
    │   ├── Contacts/contacts.vcf
    │   ├── Photos/
    │   ├── Videos/
    │   └── manifest.json
    └── ... (up to 12 successful snapshots)
```

Each manifest contains the snapshot time, counts, media access mode and SHA-256 hashes for copied files. Bellic creates the new snapshot first; only after the manifest is written and verified does it apply retention. A failed snapshot is removed and successful older snapshots are preserved.

## App features

- Plain one-screen interface
- System, Light and Dark appearance settings
- Manual **Back Up Now** action
- Daily scheduled backup aimed at 02:00 local time
- Keep the 12 newest successful snapshots
- Backup history view
- User-selected storage through Android's system folder picker
- No login, cloud service, analytics or Internet permission

## Build an installable APK with GitHub Actions

The repository includes `.github/workflows/build.yml`. After the project files are in a GitHub repository, the workflow builds `app-debug.apk` and publishes it as the `Bellic-debug-APK` artifact. In GitHub, open **Actions → Build Bellic APK → latest successful run → Artifacts → Bellic-debug-APK**.

This workflow uses an installed Gradle distribution rather than requiring a checked-in Gradle Wrapper binary.

## Android behaviour and limits

- Choose a parent folder such as **Documents** in the Android folder picker. Bellic creates `CurrentStateBackup` inside it. Newer Android versions do not permit apps to select certain storage roots or the Downloads directory via this picker.
- On Android 14 and later, the user may grant access to selected photos/videos rather than the full library. Bellic will back up only the media Android allows it to see and will flag limited access in the result.
- Android battery optimisation and Doze can delay background work. The app schedules the next backup for 02:00 local time, but Android does not guarantee execution at that exact minute. Manual backups can run as foreground work with a progress notification; daily automatic backups use ordinary deferrable work to avoid attempting a restricted foreground-service start from the background, so very large libraries may need a manual run if the OS stops the job. The device must be on, the selected folder must remain accessible, and the relevant permissions must remain granted.
- The snapshot copies available media files, not private app data or an entire-device image. It does not back up SMS, call logs, documents or Downloads.
- Retention requires the selected document provider to allow folder deletion. If Android or the provider refuses to delete an older snapshot, Bellic preserves the new successful snapshot and reports the retention issue rather than falsely reporting cleanup success.

## Build configuration

- Application ID: `com.bellic.backup`
- Minimum Android version: Android 8.0 (API 26)
- Compile SDK: 36; target SDK: 35
- Version: `1.0.0`
