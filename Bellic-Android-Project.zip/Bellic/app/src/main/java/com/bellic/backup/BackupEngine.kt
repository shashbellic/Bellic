package com.bellic.backup

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

internal data class BackupSummary(
    val folderName: String,
    val createdAt: String,
    val contactCount: Int,
    val photoCount: Int,
    val videoCount: Int,
    val partialMediaAccess: Boolean,
    val retentionWarning: Boolean
)

private data class ContactEntry(
    val id: String,
    val displayName: String,
    var given: String = "",
    var middle: String = "",
    var family: String = "",
    var prefix: String = "",
    var suffix: String = "",
    val phones: MutableList<Pair<String, Int>> = mutableListOf(),
    val emails: MutableList<String> = mutableListOf()
)

private data class FileEntry(
    val category: String,
    val name: String,
    val size: Long,
    val sha256: String,
    val mimeType: String
)

internal class BackupEngine(private val context: Context) {
    private val resolver = context.contentResolver
    private val timestampFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss", Locale.US)

    fun performBackup(progress: (String) -> Unit): BackupSummary {
        val savedUri = BellicPrefs.prefs(context).getString(BellicPrefs.TREE_URI, null)
            ?: throw IOException("Choose a backup location first")
        val treeUri = Uri.parse(savedUri)
        val selectedParent = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IOException("The selected backup location is no longer available. Choose it again.")
        if (!selectedParent.canWrite()) throw IOException("The selected backup location is not writable. Choose another folder.")

        checkRequiredPermissions()
        val root = getOrCreateDirectory(selectedParent, "CurrentStateBackup")
        removeStaleIncompleteBackups(root)

        val folderName = uniqueBackupName(root)
        val backupDirectory = root.createDirectory(folderName)
            ?: throw IOException("Could not create the new backup folder")
        var completed = false
        try {
            progress("Exporting contacts")
            val entries = mutableListOf<FileEntry>()
            val contactsDirectory = getOrCreateDirectory(backupDirectory, "Contacts")
            val contactData = readContactsAsVCard()
            val contactsFile = contactsDirectory.createFile("text/vcard", "contacts.vcf")
                ?: throw IOException("Could not create contacts.vcf")
            val contactBytes = contactData.vcard.toByteArray(Charsets.UTF_8)
            writeBytes(contactsFile, contactBytes)
            entries += FileEntry("Contacts", "contacts.vcf", contactBytes.size.toLong(), sha256(contactBytes), "text/vcard")

            progress("Copying photos")
            val photosDirectory = getOrCreateDirectory(backupDirectory, "Photos")
            val photoCount = copyMediaCollection(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                photosDirectory,
                "Photo",
                entries,
                progress
            )

            progress("Copying videos")
            val videosDirectory = getOrCreateDirectory(backupDirectory, "Videos")
            val videoCount = copyMediaCollection(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videosDirectory,
                "Video",
                entries,
                progress
            )

            val now = Instant.now().toString()
            val localCreatedAt = LocalDateTime.now().toString()
            val manifest = JSONObject()
                .put("app", "Bellic")
                .put("formatVersion", 1)
                .put("status", "success")
                .put("createdAt", now)
                .put("createdAtLocal", localCreatedAt)
                .put("backupFolder", folderName)
                .put("contacts", contactData.contactCount)
                .put("photos", photoCount)
                .put("videos", videoCount)
                .put("mediaAccess", if (hasFullMediaAccess()) "full" else "selected-only")
                .put("files", JSONArray().apply {
                    entries.forEach { entry ->
                        put(JSONObject()
                            .put("category", entry.category)
                            .put("name", entry.name)
                            .put("sizeBytes", entry.size)
                            .put("sha256", entry.sha256)
                            .put("mimeType", entry.mimeType))
                    }
                })
            val manifestFile = backupDirectory.createFile("application/json", "manifest.json")
                ?: throw IOException("Could not write the backup manifest")
            writeBytes(manifestFile, manifest.toString(2).toByteArray(Charsets.UTF_8))
            verifyManifest(manifestFile)
            completed = true

            progress("Applying 12-backup retention")
            val retentionWarning = try {
                !applyRetention(root, folderName)
            } catch (_: Exception) {
                true
            }
            return BackupSummary(
                folderName = folderName,
                createdAt = now,
                contactCount = contactData.contactCount,
                photoCount = photoCount,
                videoCount = videoCount,
                partialMediaAccess = !hasFullMediaAccess(),
                retentionWarning = retentionWarning
            )
        } finally {
            if (!completed) backupDirectory.delete()
        }
    }

    private data class ContactsExport(val vcard: String, val contactCount: Int)

    private fun readContactsAsVCard(): ContactsExport {
        val entries = linkedMapOf<String, ContactEntry>()
        val contactProjection = arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME)
        resolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            contactProjection,
            null,
            null,
            ContactsContract.Contacts.DISPLAY_NAME + " COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
            val nameIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idIndex) ?: continue
                val displayName = cursor.getString(nameIndex).orEmpty().ifBlank { "Contact" }
                entries[id] = ContactEntry(id = id, displayName = displayName)
            }
        } ?: throw IOException("Could not read contacts")

        resolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(
                ContactsContract.Data.CONTACT_ID,
                ContactsContract.CommonDataKinds.StructuredName.PREFIX,
                ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME,
                ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME,
                ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME,
                ContactsContract.CommonDataKinds.StructuredName.SUFFIX
            ),
            ContactsContract.Data.MIMETYPE + " = ?",
            arrayOf(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE),
            null
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.Data.CONTACT_ID)
            val prefixIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredName.PREFIX)
            val givenIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME)
            val middleIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME)
            val familyIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME)
            val suffixIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredName.SUFFIX)
            while (cursor.moveToNext()) {
                val contact = entries[cursor.getString(idIndex)] ?: continue
                contact.prefix = cursor.getString(prefixIndex).orEmpty()
                contact.given = cursor.getString(givenIndex).orEmpty()
                contact.middle = cursor.getString(middleIndex).orEmpty()
                contact.family = cursor.getString(familyIndex).orEmpty()
                contact.suffix = cursor.getString(suffixIndex).orEmpty()
            }
        } ?: throw IOException("Could not read contact names")

        resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE
            ), null, null, null
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numberIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
            while (cursor.moveToNext()) {
                val entry = entries[cursor.getString(idIndex)] ?: continue
                val value = cursor.getString(numberIndex).orEmpty().trim()
                if (value.isNotEmpty()) entry.phones.add(value to cursor.getInt(typeIndex))
            }
        } ?: throw IOException("Could not read contact phone numbers")

        resolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                ContactsContract.CommonDataKinds.Email.ADDRESS
            ), null, null, null
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
            val emailIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
            while (cursor.moveToNext()) {
                val entry = entries[cursor.getString(idIndex)] ?: continue
                val value = cursor.getString(emailIndex).orEmpty().trim()
                if (value.isNotEmpty()) entry.emails += value
            }
        } ?: throw IOException("Could not read contact email addresses")

        val output = StringBuilder()
        entries.values.forEach { contact ->
            output.append("BEGIN:VCARD\r\nVERSION:3.0\r\n")
            output.append("FN:").append(escapeVCard(contact.displayName)).append("\r\n")
            output.append("N:").append(escapeVCard(contact.family)).append(';')
                .append(escapeVCard(contact.given)).append(';')
                .append(escapeVCard(contact.middle)).append(';')
                .append(escapeVCard(contact.prefix)).append(';')
                .append(escapeVCard(contact.suffix)).append("\r\n")
            contact.phones.distinct().forEach { (number, type) ->
                val typeName = when (type) {
                    ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE -> "CELL"
                    ContactsContract.CommonDataKinds.Phone.TYPE_WORK,
                    ContactsContract.CommonDataKinds.Phone.TYPE_WORK_MOBILE -> "WORK"
                    ContactsContract.CommonDataKinds.Phone.TYPE_HOME -> "HOME"
                    else -> "VOICE"
                }
                output.append("TEL;TYPE=").append(typeName).append(':')
                    .append(escapeVCard(number)).append("\r\n")
            }
            contact.emails.distinct().forEach { email ->
                output.append("EMAIL;TYPE=INTERNET:").append(escapeVCard(email)).append("\r\n")
            }
            output.append("END:VCARD\r\n")
        }
        return ContactsExport(output.toString(), entries.size)
    }

    private fun copyMediaCollection(
        collection: Uri,
        destination: DocumentFile,
        category: String,
        manifestEntries: MutableList<FileEntry>,
        progress: (String) -> Unit
    ): Int {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE
        )
        var count = 0
        val usedNames = mutableSetOf<String>()
        resolver.query(collection, projection, null, null, MediaStore.MediaColumns.DATE_ADDED + " ASC")?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val mimeIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIndex)
                val displayName = cursor.getString(nameIndex).orEmpty()
                val mimeType = cursor.getString(mimeIndex)?.takeIf { it.isNotBlank() }
                    ?: if (category == "Photo") "image/jpeg" else "video/mp4"
                val baseName = safeFileName(displayName, category.lowercase(Locale.US), id, mimeType)
                val fileName = uniqueFileName(baseName, usedNames)
                val source = ContentUris.withAppendedId(collection, id)
                val destFile = destination.createFile(mimeType, fileName)
                    ?: throw IOException("Could not create $category file: $fileName")
                try {
                    val copied = copyAndHash(source, destFile)
                    val expected = cursor.getLong(sizeIndex)
                    if (expected > 0L && copied.first != expected) {
                        throw IOException("File size changed or could not be copied fully: $fileName")
                    }
                    val storedLength = destFile.length()
                    if (storedLength > 0 && storedLength != copied.first) {
                        throw IOException("Destination verification failed for $fileName")
                    }
                    manifestEntries += FileEntry(category, fileName, copied.first, copied.second, mimeType)
                    count++
                    if (count % 100 == 0) progress("Copying ${category.lowercase(Locale.US)}s · $count files")
                } catch (e: Exception) {
                    destFile.delete()
                    throw e
                }
            }
        } ?: throw IOException("Could not read the device ${category.lowercase(Locale.US)} library")
        return count
    }

    private fun copyAndHash(source: Uri, destination: DocumentFile): Pair<Long, String> {
        val input = resolver.openInputStream(source)
            ?: throw IOException("Could not open source media item")
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        BufferedInputStream(input).use { bufferedInput ->
            val output = resolver.openOutputStream(destination.uri, "w")
                ?: throw IOException("Could not write to the selected backup folder")
            BufferedOutputStream(output).use { bufferedOutput ->
                val buffer = ByteArray(128 * 1024)
                while (true) {
                    val read = bufferedInput.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    bufferedOutput.write(buffer, 0, read)
                    digest.update(buffer, 0, read)
                    total += read
                }
                bufferedOutput.flush()
            }
        }
        return total to digest.digest().toHex()
    }

    private fun writeBytes(file: DocumentFile, bytes: ByteArray) {
        val output = resolver.openOutputStream(file.uri, "w") ?: throw IOException("Could not write ${file.name}")
        output.use { stream -> stream.write(bytes); stream.flush() }
        val size = file.length()
        if (size > 0L && size != bytes.size.toLong()) throw IOException("Could not verify ${file.name}")
    }

    private fun verifyManifest(file: DocumentFile) {
        val text = resolver.openInputStream(file.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IOException("Could not verify backup manifest")
        if (!text.contains("\"status\": \"success\"")) throw IOException("Backup manifest verification failed")
    }

    private fun getOrCreateDirectory(parent: DocumentFile, name: String): DocumentFile {
        val current = parent.findFile(name)
        if (current != null) {
            if (!current.isDirectory) throw IOException("A file named $name already exists in the selected location")
            return current
        }
        return parent.createDirectory(name) ?: throw IOException("Could not create folder $name")
    }

    private fun uniqueBackupName(root: DocumentFile): String {
        val base = LocalDateTime.now().format(timestampFormatter)
        var candidate = base
        var suffix = 1
        while (root.findFile(candidate) != null) {
            candidate = "${base}_${suffix.toString().padStart(2, '0')}"
            suffix++
        }
        return candidate
    }

    private fun removeStaleIncompleteBackups(root: DocumentFile) {
        val pattern = Regex("\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}(?:_\\d+)?")
        root.listFiles().filter { it.isDirectory && pattern.matches(it.name.orEmpty()) }.forEach { dir ->
            if (!isSuccessfulBackup(dir)) dir.delete()
        }
    }

    /** The retention routine is intentionally called only after the new manifest has been verified. */
    private fun applyRetention(root: DocumentFile, newFolderName: String): Boolean {
        val pattern = Regex("\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}(?:_\\d+)?")
        val successful = root.listFiles()
            .filter { it.isDirectory && pattern.matches(it.name.orEmpty()) && isSuccessfulBackup(it) }
            .sortedBy { it.name.orEmpty() }
        val older = successful.filter { it.name != newFolderName }
            .sortedByDescending { it.name.orEmpty() }
            .drop(11)
        var allDeleted = true
        older.forEach { if (!it.delete()) allDeleted = false }
        return allDeleted
    }

    private fun isSuccessfulBackup(directory: DocumentFile): Boolean {
        val manifest = directory.findFile("manifest.json") ?: return false
        return try {
            resolver.openInputStream(manifest.uri)?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                reader.readText().contains("\"status\": \"success\"")
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun checkRequiredPermissions() {
        val contactsGranted = context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!contactsGranted) throw SecurityException("Allow Contacts permission in Android settings")
        if (Build.VERSION.SDK_INT >= 33) {
            val selected = Build.VERSION.SDK_INT >= 34 && context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val images = context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val videos = context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!images && !selected) throw SecurityException("Allow photo access in Android settings")
            if (!videos && !selected) throw SecurityException("Allow video access in Android settings")
        } else {
            val storageGranted = context.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!storageGranted) throw SecurityException("Allow photo and video access in Android settings")
        }
    }

    private fun hasFullMediaAccess(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
            context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO) == android.content.pm.PackageManager.PERMISSION_GRANTED
    } else {
        context.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun safeFileName(input: String, prefix: String, id: Long, mimeType: String): String {
        var name = input.trim().replace(Regex("[\\u0000-\\u001F\\\\/:*?\"<>|]"), "_").trim('.',' ')
        if (name.isBlank()) {
            val extension = when {
                mimeType.endsWith("png", true) -> ".png"
                mimeType.endsWith("webp", true) -> ".webp"
                mimeType.endsWith("gif", true) -> ".gif"
                mimeType.endsWith("heic", true) -> ".heic"
                mimeType.endsWith("heif", true) -> ".heif"
                mimeType.endsWith("3gpp", true) -> ".3gp"
                mimeType.endsWith("quicktime", true) -> ".mov"
                mimeType.startsWith("video/", true) -> ".mp4"
                else -> ".jpg"
            }
            name = "${prefix}_$id$extension"
        }
        return Normalizer.normalize(name, Normalizer.Form.NFC).take(180)
    }

    private fun uniqueFileName(candidate: String, used: MutableSet<String>): String {
        if (used.add(candidate.lowercase(Locale.ROOT))) return candidate
        val dot = candidate.lastIndexOf('.')
        val stem = if (dot > 0) candidate.substring(0, dot) else candidate
        val extension = if (dot > 0) candidate.substring(dot) else ""
        var index = 2
        while (true) {
            val next = "${stem}_$index$extension"
            if (used.add(next.lowercase(Locale.ROOT))) return next
            index++
        }
    }

    private fun escapeVCard(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
        .replace("\r", "\\n")
        .replace(";", "\\;")
        .replace(",", "\\,")

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).toHex()

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
