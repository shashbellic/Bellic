package com.bellic.backup

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

object BellicPrefs {
    const val FILE_NAME = "bellic_preferences"
    const val TREE_URI = "tree_uri"
    const val LAST_SUCCESS = "last_success"
    const val LAST_STATUS = "last_status"
    const val LAST_DETAIL = "last_detail"
    const val LAST_FOLDER = "last_folder"
    const val THEME = "theme"

    fun prefs(context: Context) = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun applyTheme(context: Context) {
        val mode = prefs(context).getString(THEME, "system") ?: "system"
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun themeLabel(context: Context): String = when (prefs(context).getString(THEME, "system")) {
        "light" -> "Light"
        "dark" -> "Dark"
        else -> "System default"
    }
}
