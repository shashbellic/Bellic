package com.bellic.backup

import android.Manifest
import androidx.appcompat.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.graphics.Color
import android.content.res.Configuration
import androidx.documentfile.provider.DocumentFile
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var statusTitle: TextView
    private lateinit var statusDetail: TextView
    private lateinit var locationText: TextView
    private lateinit var backupButton: Button

    private val treePicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(this, "No folder selected.", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            BellicPrefs.prefs(this).edit().putString(BellicPrefs.TREE_URI, uri.toString()).apply()
            updateLocationText()
            refreshStatus()
            Toast.makeText(this, "Backup location saved.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not save this folder permission. Please choose another folder.", Toast.LENGTH_LONG).show()
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        if (hasRequiredPermissions()) enqueueManualBackup()
        else showPermissionHelp()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        BellicPrefs.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        configureSystemBars()

        statusTitle = findViewById(R.id.tvStatusTitle)
        statusDetail = findViewById(R.id.tvStatusDetail)
        locationText = findViewById(R.id.tvLocation)
        backupButton = findViewById(R.id.btnBackupNow)

        findViewById<Button>(R.id.btnBackupNow).setOnClickListener { onBackupPressed() }
        findViewById<Button>(R.id.btnChooseLocation).setOnClickListener { chooseLocation() }
        findViewById<Button>(R.id.btnHistory).setOnClickListener { showBackupHistory() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }

        updateLocationText()
        refreshStatus()
        DailyBackupScheduler.scheduleNext(this)

        WorkManager.getInstance(this)
            .getWorkInfosForUniqueWorkLiveData(BackupWorker.MANUAL_WORK_NAME)
            .observe(this) { refreshStatus() }
        WorkManager.getInstance(this)
            .getWorkInfosByTagLiveData(BackupWorker.DAILY_TAG)
            .observe(this) { refreshStatus() }
    }


    private fun configureSystemBars() {
        // Target SDK 35 enables edge-to-edge by default. Apply insets so controls stay clear of system bars.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val isLightTheme = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) != Configuration.UI_MODE_NIGHT_YES
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = isLightTheme
            isAppearanceLightNavigationBars = isLightTheme
        }
        val root = findViewById<android.view.View>(R.id.mainScroll)
        val left = root.paddingLeft
        val top = root.paddingTop
        val right = root.paddingRight
        val bottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(left + bars.left, top + bars.top, right + bars.right, bottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    override fun onResume() {
        super.onResume()
        updateLocationText()
        refreshStatus()
    }

    private fun onBackupPressed() {
        val tree = BellicPrefs.prefs(this).getString(BellicPrefs.TREE_URI, null)
        if (tree.isNullOrBlank()) {
            AlertDialog.Builder(this)
                .setTitle("Choose a backup location")
                .setMessage("Bellic will create a CurrentStateBackup folder inside the folder you select. Choose a parent folder such as Documents or a folder on a USB drive.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Choose folder") { _, _ -> chooseLocation() }
                .show()
            return
        }
        if (hasRequiredPermissions()) enqueueManualBackup()
        else permissionLauncher.launch(requiredPermissions())
    }

    private fun chooseLocation() {
        treePicker.launch(null)
    }

    private fun requiredPermissions(): Array<String> {
        val permissions = mutableListOf(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 34) {
            permissions += Manifest.permission.READ_MEDIA_IMAGES
            permissions += Manifest.permission.READ_MEDIA_VIDEO
            permissions += Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        } else if (Build.VERSION.SDK_INT >= 33) {
            permissions += Manifest.permission.READ_MEDIA_IMAGES
            permissions += Manifest.permission.READ_MEDIA_VIDEO
        } else {
            permissions += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return permissions.toTypedArray()
    }

    private fun hasRequiredPermissions(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return false
        if (Build.VERSION.SDK_INT >= 33) {
            val images = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
            val videos = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            val selected = Build.VERSION.SDK_INT >= 34 && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
            return (images || selected) && (videos || selected)
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun showPermissionHelp() {
        AlertDialog.Builder(this)
            .setTitle("Permissions needed")
            .setMessage("Bellic needs Contacts access and photo/video access to back up the three selected data types. On Android 14 and newer, limited media access backs up only the items you selected. You can change access in Android Settings → Apps → Bellic → Permissions.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun enqueueManualBackup() {
        val request = OneTimeWorkRequestBuilder<BackupWorker>().build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            BackupWorker.MANUAL_WORK_NAME,
            ExistingWorkPolicy.KEEP,
            request
        )
        refreshStatus(runningOverride = true)
    }

    private fun refreshStatus(runningOverride: Boolean = false) {
        if (!::statusTitle.isInitialized) return
        val workManager = WorkManager.getInstance(this)
        val manual = workManager.getWorkInfosForUniqueWorkLiveData(BackupWorker.MANUAL_WORK_NAME).value.orEmpty()
        val daily = workManager.getWorkInfosByTagLiveData(BackupWorker.DAILY_TAG).value.orEmpty()
        val running = runningOverride || manual.any { it.state == WorkInfo.State.RUNNING } || daily.any { it.state == WorkInfo.State.RUNNING }
        val prefs = BellicPrefs.prefs(this)
        if (running) {
            statusTitle.text = "Backup in progress"
            statusDetail.text = "Bellic is copying your contacts, photos and videos. Older successful backups are being kept safe."
            backupButton.isEnabled = false
            backupButton.text = "Backup in progress…"
            return
        }
        backupButton.isEnabled = true
        backupButton.text = getString(R.string.backup_now)
        val status = prefs.getString(BellicPrefs.LAST_STATUS, "")
        val detail = prefs.getString(BellicPrefs.LAST_DETAIL, "")
        when (status) {
            "success" -> {
                statusTitle.text = "Last backup succeeded"
                val lastSuccess = prefs.getString(BellicPrefs.LAST_SUCCESS, null)?.let { formatDate(it) }
                statusDetail.text = buildString {
                    if (!lastSuccess.isNullOrBlank()) append("$lastSuccess\n")
                    append(detail.orEmpty())
                }
            }
            "failed" -> {
                statusTitle.text = "Last backup needs attention"
                statusDetail.text = detail ?: "The last backup failed. Existing backups were kept."
            }
            else -> {
                val locationChosen = !prefs.getString(BellicPrefs.TREE_URI, null).isNullOrBlank()
                statusTitle.text = if (locationChosen) "Ready to back up" else "Ready when you are"
                statusDetail.text = if (locationChosen) {
                    "Your backup location is ready. Tap Back Up Now to save contacts, photos and videos."
                } else {
                    "Choose a backup location, then tap Back Up Now."
                }
            }
        }
    }

    private fun updateLocationText() {
        if (!::locationText.isInitialized) return
        val uriText = BellicPrefs.prefs(this).getString(BellicPrefs.TREE_URI, null)
        if (uriText.isNullOrBlank()) {
            locationText.text = "Backup location: Not selected"
            return
        }
        val folder = try {
            DocumentsContract.getTreeDocumentId(Uri.parse(uriText)).substringAfter(':').ifBlank { "Selected folder" }
        } catch (_: Exception) {
            "Selected folder"
        }
        locationText.text = "Backup location: $folder / CurrentStateBackup"
    }

    private fun showBackupHistory() {
        val uriText = BellicPrefs.prefs(this).getString(BellicPrefs.TREE_URI, null)
        if (uriText.isNullOrBlank()) {
            AlertDialog.Builder(this).setTitle("Backup history")
                .setMessage("Choose a backup location first.")
                .setPositiveButton("OK", null).show()
            return
        }
        try {
            val selected = DocumentFile.fromTreeUri(this, Uri.parse(uriText))
            val root = selected?.findFile("CurrentStateBackup")
            val backups = root?.listFiles().orEmpty()
                .filter { it.isDirectory && it.findFile("manifest.json") != null && it.name?.matches(Regex("\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}(?:_\\d+)?")) == true }
                .sortedByDescending { it.name.orEmpty() }
            val message = if (backups.isEmpty()) "No successful backups found yet." else backups.take(12).joinToString("\n") { it.name.orEmpty() }
            AlertDialog.Builder(this)
                .setTitle("Backup history · ${backups.size.coerceAtMost(12)} of 12")
                .setMessage(message)
                .setPositiveButton("Done", null)
                .show()
        } catch (_: Exception) {
            AlertDialog.Builder(this)
                .setTitle("Backup history")
                .setMessage("Bellic could not read this location. Choose the backup location again.")
                .setPositiveButton("OK", null).show()
        }
    }

    private fun showSettings() {
        val labels = arrayOf("System default", "Light", "Dark")
        val values = arrayOf("system", "light", "dark")
        val current = BellicPrefs.prefs(this).getString(BellicPrefs.THEME, "system")
        val selected = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Appearance")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                BellicPrefs.prefs(this).edit().putString(BellicPrefs.THEME, values[which]).apply()
                dialog.dismiss()
                BellicPrefs.applyTheme(this)
                recreate()
            }
            .setNegativeButton("Done", null)
            .show()
    }

    private fun formatDate(value: String): String = try {
        val instant = Instant.parse(value)
        DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm", Locale.getDefault())
            .withZone(ZoneId.systemDefault()).format(instant)
    } catch (_: Exception) {
        value
    }
}
