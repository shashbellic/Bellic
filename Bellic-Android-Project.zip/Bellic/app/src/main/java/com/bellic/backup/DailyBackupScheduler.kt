package com.bellic.backup

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

object DailyBackupScheduler {
    private val nameFormatter = DateTimeFormatter.ofPattern("yyyyMMdd")

    /** Schedules one future run at the next local 02:00. WorkManager may delay it for system limits. */
    fun scheduleNext(context: Context) {
        val now = LocalDateTime.now()
        var target = now.toLocalDate().atTime(2, 0)
        if (!target.isAfter(now)) target = target.plusDays(1)
        val zone = ZoneId.systemDefault()
        val delay = Duration.between(now.atZone(zone), target.atZone(zone)).toMillis().coerceAtLeast(1_000L)
        val uniqueName = "bellic_daily_${target.format(nameFormatter)}"
        val request = OneTimeWorkRequestBuilder<BackupWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(BackupWorker.KEY_SCHEDULED to true))
            .addTag(BackupWorker.DAILY_TAG)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            uniqueName,
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}
