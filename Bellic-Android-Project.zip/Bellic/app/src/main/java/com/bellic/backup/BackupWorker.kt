package com.bellic.backup

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex

class BackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val scheduled = inputData.getBoolean(KEY_SCHEDULED, false)
        val prefs = BellicPrefs.prefs(applicationContext)
        return try {
            BACKUP_LOCK.lock()
            try {
                prefs.edit().putString(BellicPrefs.LAST_STATUS, "running")
                    .putString(BellicPrefs.LAST_DETAIL, "Backup is in progress.").apply()
                // Manual work is launched from a visible user action, so it can show foreground progress.
                // The daily job deliberately remains ordinary deferrable work because Android restricts
                // foreground-service starts from the background.
                if (!scheduled) setForeground(createForegroundInfo("Preparing backup"))
                val summary = withContext(Dispatchers.IO) {
                    BackupEngine(applicationContext).performBackup { message ->
                        if (!scheduled) setForegroundAsync(createForegroundInfo(message))
                    }
                }
                val detail = buildString {
                    append("Saved ${summary.contactCount} contacts, ${summary.photoCount} photos and ${summary.videoCount} videos.")
                    append("\nFolder: ${summary.folderName}")
                    if (summary.partialMediaAccess) {
                        append("\nPhoto/video access is limited. Grant full access in Android settings to include all media.")
                    }
                    if (summary.retentionWarning) {
                        append("\nThe new backup succeeded, but an older backup could not be removed.")
                    }
                }
                prefs.edit()
                    .putString(BellicPrefs.LAST_STATUS, "success")
                    .putString(BellicPrefs.LAST_DETAIL, detail)
                    .putString(BellicPrefs.LAST_SUCCESS, summary.createdAt)
                    .putString(BellicPrefs.LAST_FOLDER, summary.folderName)
                    .apply()
                Result.success(workDataOf("folder" to summary.folderName))
            } finally {
                BACKUP_LOCK.unlock()
            }
        } catch (e: Exception) {
            val reason = (e.message ?: e.javaClass.simpleName).take(250)
            prefs.edit()
                .putString(BellicPrefs.LAST_STATUS, "failed")
                .putString(BellicPrefs.LAST_DETAIL, "Backup failed: $reason. Existing successful backups were kept.")
                .apply()
            Result.failure(workDataOf("error" to reason))
        } finally {
            if (scheduled) runCatching { DailyBackupScheduler.scheduleNext(applicationContext) }
        }
    }

    private fun createForegroundInfo(message: String): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Bellic backups", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shows progress while Bellic backs up your data."
                }
            )
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Bellic backup")
            .setContentText(message)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        const val KEY_SCHEDULED = "scheduled_backup"
        const val DAILY_TAG = "bellic_daily_backup"
        const val MANUAL_WORK_NAME = "bellic_manual_backup"
        private const val CHANNEL_ID = "bellic_backup_progress"
        private const val NOTIFICATION_ID = 7419
        private val BACKUP_LOCK = Mutex()
    }
}
